package AKT;

//package com.virtualmarketplace; // Replace with your package name (e.g., AKT)

/*2.4 Test the View Products Functionality
Run the ArtisanDashboard.java file.

Click View Products to open the ViewProductsForm.

Verify the products added by the artisan are displayed.*/

/*2.3 Explanation of the Code
View Products Form:

Displays a list of products added by the logged-in artisan.

A Back button to return to the ArtisanDashboard.

loadProducts() Method:

Fetches products from the Products table for the logged-in artisan (hardcoded to artisan_id = 1 for now).*/
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewProductsForm extends JFrame {
    private JTextArea productsArea;
    private JButton backButton;

    public ViewProductsForm() {
        setTitle("View Products");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        productsArea = new JTextArea(15, 40);
        productsArea.setEditable(false);
        backButton = new JButton("Back");

        add(new JScrollPane(productsArea));
        add(backButton);

        loadProducts();

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ArtisanDashboard().setVisible(true); // Open Artisan Dashboard
                dispose(); // Close this form
            }
        });
    }

    private void loadProducts() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM Products WHERE artisan_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, 1); // Replace with the logged-in artisan's ID
            ResultSet rs = pstmt.executeQuery();

            StringBuilder products = new StringBuilder();
            while (rs.next()) {
                products.append("ID: ").append(rs.getInt("product_id"))
                        .append(", Name: ").append(rs.getString("name"))
                        .append(", Price: ").append(rs.getDouble("price"))
                        .append(", Category: ").append(rs.getString("category"))
                        .append("\n");
            }
            productsArea.setText(products.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading products: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ViewProductsForm().setVisible(true);
        });
    }
}