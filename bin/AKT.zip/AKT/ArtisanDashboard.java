package AKT;// Replace with your package name
//The Artisan Dashboard will allow artisans to manage their products.
/*2.3 Explanation of the Code
Artisan Dashboard:

Contains buttons to Add Product, View Products, and Logout.

Clicking Add Product opens the AddProductForm (we’ll create this next).

Clicking Logout takes the user back to the LoginForm.*/
//package com.virtualmarketplace; // Replace with your package name (e.g., AKT)
/*Step 2: Implement the View Products Functionality
The View Products functionality will display a list of products added by the logged-in artisan.

2.1 Update the ArtisanDashboard Class
Add a View Products button to the ArtisanDashboard.java file:*/
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ArtisanDashboard extends JFrame {
    private JButton addProductButton, viewProductsButton, logoutButton;

    public ArtisanDashboard() {
        setTitle("Artisan Dashboard");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        addProductButton = new JButton("Add Product");
        viewProductsButton = new JButton("View Products");
        logoutButton = new JButton("Logout");

        add(addProductButton);
        add(viewProductsButton);
        add(logoutButton);

        addProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddProductForm().setVisible(true); // Open Add Product Form
                dispose(); // Close the dashboard
            }
        });

        viewProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ViewProductsForm().setVisible(true); // Open View Products Form
                dispose(); // Close the dashboard
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginForm().setVisible(true); // Open Login Form
                dispose(); // Close the dashboard
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ArtisanDashboard().setVisible(true);
        });
    }
}