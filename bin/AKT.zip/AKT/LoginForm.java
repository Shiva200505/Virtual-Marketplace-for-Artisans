package AKT; // Replace with your package name
/*1.3 Explanation of the Code
Login Form:

Contains fields for email and password.

A Login button to validate the user.

loginUser() Method:

Checks if the user is an artisan or customer by querying the database.

If the login is successful, it opens the respective dashboard (ArtisanDashboard or CustomerDashboard).

ArtisanDashboard and CustomerDashboard:

We’ll create these classes next.*/
import AKT.CustomerDashboard; // Replace with your package name (e.g., AKT)

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginForm extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginForm() {
        setTitle("Login Form");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");

        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginUser();
            }
        });
    }

    private void loginUser() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        // Debug: Print email and password
        System.out.println("Email: " + email);
        System.out.println("Password: " + password);

        try (Connection conn = DBConnection.getConnection()) {
            // Check if the user is an artisan
            String artisanQuery = "SELECT * FROM Artisans WHERE email = ? AND password = ?";
            PreparedStatement artisanStmt = conn.prepareStatement(artisanQuery);
            artisanStmt.setString(1, email);
            artisanStmt.setString(2, password);
            ResultSet artisanRs = artisanStmt.executeQuery();

            if (artisanRs.next()) {
                JOptionPane.showMessageDialog(this, "Artisan login successful!");
                new ArtisanDashboard().setVisible(true); // Open Artisan Dashboard
                dispose(); // Close the login form
                return;
            }

            // Check if the user is a customer
            String customerQuery = "SELECT * FROM Customers WHERE email = ? AND password = ?";
            PreparedStatement customerStmt = conn.prepareStatement(customerQuery);
            customerStmt.setString(1, email);
            customerStmt.setString(2, password);
            ResultSet customerRs = customerStmt.executeQuery();

            if (customerRs.next()) {
                JOptionPane.showMessageDialog(this, "Customer login successful!");
                new CustomerDashboard().setVisible(true); // Open Customer Dashboard
                dispose(); // Close the login form
                return;
            }

            JOptionPane.showMessageDialog(this, "Invalid email or password!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }
}