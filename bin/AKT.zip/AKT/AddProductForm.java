package AKT;// Replace with your package name
//The Add Product Form will allow artisans to add new products.
/*3.3 Explanation of the Code
Add Product Form:

Contains fields for product name, price, category, and description.

A button to add the product to the database.

addProduct() Method:

Inserts the product details into the Products table.*/
//package com.virtualmarketplace; // Replace with your package name (e.g., AKT)

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddProductForm extends JFrame {
    private JTextField nameField, priceField, categoryField;
    private JTextArea descriptionArea;
    private JButton addButton;

    public AddProductForm() {
        setTitle("Add Product");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        nameField = new JTextField(20);
        priceField = new JTextField(20);
        categoryField = new JTextField(20);
        descriptionArea = new JTextArea(5, 20);
        addButton = new JButton("Add Product");

        add(new JLabel("Product Name:"));
        add(nameField);
        add(new JLabel("Price:"));
        add(priceField);
        add(new JLabel("Category:"));
        add(categoryField);
        add(new JLabel("Description:"));
        add(new JScrollPane(descriptionArea));
        add(addButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProduct();
            }
        });
    }

    private void addProduct() {
        String name = nameField.getText();
        double price = Double.parseDouble(priceField.getText());
        String category = categoryField.getText();
        String description = descriptionArea.getText();

        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO Products (name, price, category, description, artisan_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setDouble(2, price);
            pstmt.setString(3, category);
            pstmt.setString(4, description);
            pstmt.setInt(5, 1); // Replace with the logged-in artisan's ID
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Product added successfully!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AddProductForm().setVisible(true);
        });
    }
}