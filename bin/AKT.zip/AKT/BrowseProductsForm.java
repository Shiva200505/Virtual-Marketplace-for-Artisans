package AKT;	// Replace with your package name (e.g., AKT)
//The Browse Products Form will allow customers to browse and purchase products.

//package com.virtualmarketplace; // Replace with your package name (e.g., AKT)

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BrowseProductsForm extends JFrame {
    private JTextArea productsArea;
    private JTextField productIdField;
    private JButton purchaseButton, backButton;

    public BrowseProductsForm() {
        setTitle("Browse Products");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        productsArea = new JTextArea(15, 40);
        productsArea.setEditable(false);
        productIdField = new JTextField(10);
        purchaseButton = new JButton("Purchase");
        backButton = new JButton("Back");

        add(new JScrollPane(productsArea));
        add(new JLabel("Enter Product ID to Purchase:"));
        add(productIdField);
        add(purchaseButton);
        add(backButton);

        loadProducts();

        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                purchaseProduct();
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CustomerDashboard().setVisible(true); // Open Customer Dashboard
                dispose(); // Close this form
            }
        });
    }

    private void loadProducts() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM Products";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            StringBuilder products = new StringBuilder();
            while (rs.next()) {
                products.append("ID: ").append(rs.getInt("product_id"))
                        .append(", Name: ").append(rs.getString("name"))
                        .append(", Price: ").append(rs.getDouble("price"))
                        .append(", Category: ").append(rs.getString("category"))
                        .append("\n");
            }
            productsArea.setText(products.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading products: " + ex.getMessage());
        }
    }

    private void purchaseProduct() {
        String productId = productIdField.getText();
        if (productId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Product ID!");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Check if the product exists
            String query = "SELECT * FROM Products WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(productId));
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Insert the order into the Orders table
                String insertQuery = "INSERT INTO Orders (customer_id, product_id, quantity, order_date) VALUES (?, ?, ?, NOW())";
                PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                insertStmt.setInt(1, 1); // Replace with the logged-in customer's ID
                insertStmt.setInt(2, Integer.parseInt(productId));
                insertStmt.setInt(3, 1); // Default quantity is 1
                insertStmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Product purchased successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Product ID!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error purchasing product: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new BrowseProductsForm().setVisible(true);
        });
    }
}