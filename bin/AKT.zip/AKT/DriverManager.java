package AKT;

public class DriverManager {

	public static Connection getConnection(String url, String user, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
